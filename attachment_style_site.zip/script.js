
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.style.display = 'none');
    document.getElementById(pageId).style.display = 'block';
}

function calculateAttachmentStyle(formId, resultId) {
    const form = document.getElementById(formId);
    const values = Array.from(form.elements)
        .filter(el => el.type === 'radio' && el.checked)
        .map(el => parseInt(el.value));

    let sum = values.reduce((a, b) => a + b, 0);
    let avg = sum / values.length;

    let resultText = '';
    if (avg >= 4) {
        resultText = 'Anxious-Preoccupied: You seek high levels of intimacy and approval, but may fear abandonment.';
    } else if (avg >= 3) {
        resultText = 'Fearful-Avoidant: You want connection but push people away. You fear being hurt or losing independence.';
    } else if (avg >= 2) {
        resultText = 'Dismissive-Avoidant: You value independence and may suppress your emotions or avoid closeness.';
    } else {
        resultText = 'Secure: You’re comfortable with intimacy and independence.';
    }

    document.getElementById(resultId).innerText = resultText;
    showPage('resultsPage');
}

function calculateAttachmentStyle(formId, resultId) {
    const form = document.getElementById(formId);
    const values = Array.from(form.elements)
        .filter(el => el.type === 'radio' && el.checked)
        .map(el => parseInt(el.value));

    if (values.length === 0) {
        alert("Please answer at least one question.");
        return;
    }

    let sum = values.reduce((a, b) => a + b, 0);
    let avg = sum / values.length;

    document.getElementById('spinner').style.display = 'block';
    showPage('resultsPage');

    setTimeout(() => {
        document.getElementById('spinner').style.display = 'none';
        let resultText = '';
        if (avg >= 4) {
            resultText = '<h3>Anxious-Preoccupied</h3><p>You seek high levels of intimacy and approval, but may fear abandonment.</p>';
        } else if (avg >= 3) {
            resultText = '<h3>Fearful-Avoidant</h3><p>You want connection but push people away. You fear being hurt or losing independence.</p>';
        } else if (avg >= 2) {
            resultText = '<h3>Dismissive-Avoidant</h3><p>You value independence and may suppress your emotions or avoid closeness.</p>';
        } else {
            resultText = '<h3>Secure</h3><p>You’re comfortable with intimacy and independence.</p>';
        }

        document.getElementById(resultId).innerHTML = '<div class="result-card">' + resultText + '</div>';
    }, 2000);
}
